<!-- <?php
// Obtiene los datos enviados desde JavaScript
$data = json_decode(file_get_contents('php://input'), true);

// Verifica si se recibieron los datos correctamente
if ($data && isset($data['variable'])) {
    $variable = $data['variable'];

    // Realiza las operaciones necesarias con la variable recibida
    // ...

    // Devuelve una respuesta al cliente (JavaScript)
    echo "Variable recibida: " . $variable;
} else {
    // Si no se recibieron datos válidos, devuelve un mensaje de error
    echo "Hubo un problema al recibir la variable en PHP.";
}
?> -->




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="prueba.js"></script>
</head>

<body>
<!-- <form action="prueba_recibe.php"> -->
<form action="prueba_recibe.php" method="post">
    <input type="text" placeholder="nombre" id="nom">
    <br>
    <input type="text" placeholder="apellido" name="" id="ape">
    <br>
    <!-- <button onclick="proceso()">Enviar</button> -->
    <button type="button" onclick="proceso()">Enviar</button>

</form>
</body>

</html>


<!-- <?php
// Recibir las variables enviadas desde JavaScript
$variable1 = $_POST['var1'];
$variable2 = $_POST['var2'];

// Crear el contenido del archivo
$contenido = $variable1 . " " . $variable2;

// Escribir el contenido en un archivo
$archivo = 'ruta/archivo.txt';  // Ruta y nombre del archivo
file_put_contents($archivo, $contenido);

// Devolver una respuesta al cliente
echo "Archivo escrito exitosamente.";
?> -->
