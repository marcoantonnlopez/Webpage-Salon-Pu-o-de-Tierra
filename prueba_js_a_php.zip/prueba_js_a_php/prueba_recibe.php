<?php
print_r($_POST);


// $nombre = $_POST['nom'];
// $apellido = $_POST['ape'];

// // imprime
// echo "Nombre: " . $nombre . "<br>";
// echo "Apellido: " . $apellido;
?>
