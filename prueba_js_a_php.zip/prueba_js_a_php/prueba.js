// var variable = "Hola mundo";

// var data = {
//     variable: variable
// };

// fetch('prueba.php', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(data)
//     })
//     .then(function(response) {
//         if (response.ok) {
//             return response.text();
//         } else {
//             throw new Error('Hubo un problema al enviar la variable a PHP.');
//         }
//     })
//     .then(function(data) {
//         console.log("La variable se ha enviado correctamente a PHP.");
//         console.log("Respuesta de PHP: " + data);
//     })
//     .catch(function(error) {
//         console.log("Error en la solicitud AJAX: " + error.message);
//     });


// -------------------------------------------------------------------------------------
// // Variables en JavaScript
// var variable1 = "Hola";
// var variable2 = "Mundo";

// // Envío de las variables a PHP mediante una solicitud fetch
// fetch('escribir_archivo.php', {
//         method: 'POST',
//         body: JSON.stringify({ var1: variable1, var2: variable2 }),
//     })
//     .then(response => response.text())
//     .then(data => {
//         // Aquí puedes manejar la respuesta del archivo PHP
//         console.log(data);
//     });


// ----------------------------------------------------------------------------------------------
function proceso() {
    var nombre = $('#nom').val();
    var apellido = $('#ape').val();
    // alert(nombre);

    $.post('prueba_recibe.php', { nom: nombre, ape: apellido }, function(data) {
        if (data != null) {
            alert("Los datos se enviaron correctamente");
            window.location.href = "prueba_recibe.php"; // Redirigir a la página
            alert(nombre);
            alert(apellido);

        } else {
            alert("Los datos no se enviaron");
        }
    });


    // Envía el formulario
    // $('form').submit();
}